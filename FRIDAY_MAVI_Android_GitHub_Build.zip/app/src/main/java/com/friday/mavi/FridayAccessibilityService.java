package com.friday.mavi;
import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
public class FridayAccessibilityService extends AccessibilityService {
    static FridayAccessibilityService active;
    public void onServiceConnected(){ active=this; }
    public void onAccessibilityEvent(AccessibilityEvent event){}
    public void onInterrupt(){}
    public void onDestroy(){active=null;super.onDestroy();}
    static boolean global(int action){if(active==null)return false;return active.performGlobalAction(action);}
    static boolean clickText(String text){if(active==null)return false;AccessibilityNodeInfo root=active.getRootInActiveWindow();if(root==null)return false;try{for(AccessibilityNodeInfo n:root.findAccessibilityNodeInfosByText(text)){AccessibilityNodeInfo c=n;while(c!=null){if(c.isClickable())return c.performAction(AccessibilityNodeInfo.ACTION_CLICK);c=c.getParent();}}}catch(Exception ignored){}return false;}
}
