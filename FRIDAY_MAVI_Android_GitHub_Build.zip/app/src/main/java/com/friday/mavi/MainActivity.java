package com.friday.mavi;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
  private final int BLUE=Color.rgb(49,174,255), BG=Color.rgb(4,13,30);
  private EditText input, apiKey; private TextView log, status; private ScrollView scroll;
  private TextToSpeech tts; private boolean ai=false;
  private final ArrayList<String[]> history=new ArrayList<>();
  public void onCreate(Bundle b){ super.onCreate(b); buildUi(); tts=new TextToSpeech(this,code->{if(code==TextToSpeech.SUCCESS){tts.setLanguage(Locale.UK);tts.setPitch(1.04f);tts.setSpeechRate(.96f);}}); append("FRIDAY", "Online interface ready. Local commands available; AI is optional."); }
  private TextView label(String s,int sp){TextView t=new TextView(this); t.setText(s); t.setTextColor(BLUE);t.setTextSize(sp); t.setGravity(Gravity.CENTER);return t;}
  private GradientDrawable panel(){ GradientDrawable d=new GradientDrawable(); d.setColor(Color.rgb(11,28,54));d.setCornerRadius(22);d.setStroke(2,Color.rgb(28,97,161));return d; }
  private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(panel());return b;}
  private void buildUi(){ LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(16,20,16,12);root.setBackgroundColor(BG);setContentView(root);
    TextView title=label("◉  F R I D A Y  /  M A V I",26);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(title);
    status=label("● LOCAL MODE",12);root.addView(status);
    TextView orb=label("◎",110);root.addView(orb,new LinearLayout.LayoutParams(-1,155));
    LinearLayout options=new LinearLayout(this);Button local=button("LOCAL / AI");local.setOnClickListener(v->{ai=!ai;status.setText(ai?"● AI MODE (API REQUIRED)":"● LOCAL MODE");});options.addView(local,new LinearLayout.LayoutParams(0,54,1));Button settings=button("API KEY");settings.setOnClickListener(v->keyDialog());options.addView(settings,new LinearLayout.LayoutParams(0,54,1));root.addView(options);
    scroll=new ScrollView(this); log=new TextView(this);log.setTextColor(Color.WHITE);log.setTextSize(15);log.setPadding(16,12,16,12);log.setBackground(panel());scroll.addView(log);LinearLayout.LayoutParams sc=new LinearLayout.LayoutParams(-1,0,1);sc.setMargins(0,12,0,12);root.addView(scroll,sc);
    LinearLayout row=new LinearLayout(this); input=new EditText(this);input.setSingleLine(true);input.setHint("Ask FRIDAY...");input.setHintTextColor(Color.LTGRAY);input.setTextColor(Color.WHITE);row.addView(input,new LinearLayout.LayoutParams(0,60,1));Button send=button("➤");send.setOnClickListener(v->submit());row.addView(send,new LinearLayout.LayoutParams(68,60));Button mic=button("🎙");mic.setOnClickListener(v->listen());row.addView(mic,new LinearLayout.LayoutParams(72,60));root.addView(row);
  }
  private void keyDialog(){EditText e=new EditText(this);e.setSingleLine(true);e.setHint("API key (OpenAI-compatible)");e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);e.setText(getPreferences(0).getString("key",""));new android.app.AlertDialog.Builder(this).setTitle("AI key (Groq optional)").setMessage("API key stays in this app's local preferences. For production use, a backend proxy is safer.").setView(e).setPositiveButton("Save",(d,w)->{getPreferences(0).edit().putString("key",e.getText().toString().trim()).apply();}).setNegativeButton("Cancel",null).show();}
  private void append(String who,String msg){runOnUiThread(()->{log.append("\n"+who+": "+msg+"\n");scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));});}
  private void speak(String s){runOnUiThread(()->{if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"friday");});}
  private void reply(String s){append("FRIDAY",s);speak(s);}
  private void submit(){String s=input.getText().toString().trim();if(s.isEmpty())return;input.setText("");append("YOU",s);if(ai){askAi(s);}else{local(s);}}
  private void open(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){reply("No app available to open this link.");}}
  private void local(String raw){String s=raw.toLowerCase(Locale.ROOT).replace("friday","").replace("фрайдей","").trim();
    if(s.contains("домой")||s.equals("home")){reply(FridayAccessibilityService.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)?"Home.":"Enable FRIDAY Screen Control in Android Accessibility settings first.");return;}
    if(s.contains("назад")||s.equals("back")){reply(FridayAccessibilityService.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)?"Back.":"Enable FRIDAY Screen Control in Android Accessibility settings first.");return;}
    if(s.startsWith("нажми ")||s.startsWith("click ")){String target=s.replaceFirst("^(нажми |click )","");reply(FridayAccessibilityService.clickText(target)?"Pressed "+target:"I could not find a clickable item: "+target);return;}
    if(s.contains("youtube")||s.contains("ютуб")){open("https://youtube.com");reply("Opening YouTube.");return;}
    if(s.contains("карты")||s.contains("maps")){open("https://maps.google.com");reply("Opening Maps.");return;}
    if(s.contains("telegram")||s.contains("телеграм")){open("https://t.me");reply("Opening Telegram.");return;}
    if(s.startsWith("найди ")||s.startsWith("search ")){String q=s.replaceFirst("^(найди |search )","");open("https://www.google.com/search?q="+Uri.encode(q));reply("Searching the web.");return;}
    if(s.contains("время")||s.contains("time")){reply(new java.text.SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));return;}
    if(s.contains("умеешь")||s.contains("help")){reply("I can open YouTube, Maps, Telegram, search the web, tell time, and run Back, Home or Click with Android Accessibility permission. Enable AI mode and add a key for general conversation.");return;}
    reply("Local mode supports a limited command set. Switch to AI mode in the top bar for general conversation.");
  }
  private void listen(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},20);return;}try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ru-RU");startActivityForResult(i,8);}catch(Exception ex){reply("Speech recognition is not available on this device.");}}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==8 && result==RESULT_OK && data!=null){ArrayList<String> a=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(a!=null&&!a.isEmpty()){input.setText(a.get(0));submit();}}}
  private void askAi(String prompt){String key=getPreferences(0).getString("key","");if(key.isEmpty()){reply("Add your API key in settings, or switch to Local mode.");return;}
    new Thread(()->{try{URL url=new URL("https://api.groq.com/openai/v1/chat/completions");HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(40000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+key);
      JSONArray m=new JSONArray();m.put(new JSONObject().put("role","system").put("content","You are FRIDAY, a concise and helpful Android assistant. Give accurate, safe advice. You cannot control the phone through this chat; local commands handle device actions."));int from=Math.max(0,history.size()-8);for(int j=from;j<history.size();j++){String[] p=history.get(j);m.put(new JSONObject().put("role",p[0]).put("content",p[1]));}m.put(new JSONObject().put("role","user").put("content",prompt));JSONObject body=new JSONObject().put("model","openai/gpt-oss-20b").put("messages",m).put("max_tokens",450);
      try(OutputStream out=c.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}int code=c.getResponseCode();InputStream stream=code<400?c.getInputStream():c.getErrorStream();ByteArrayOutputStream bos=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=stream.read(buf))!=-1)bos.write(buf,0,n);String res=bos.toString("UTF-8");if(code>=400){reply("AI HTTP "+code+": "+res.substring(0,Math.min(180,res.length())));return;}String answer=new JSONObject(res).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content","No response");history.add(new String[]{"user",prompt});history.add(new String[]{"assistant",answer});reply(answer);
    }catch(Exception e){reply("AI request failed: "+e.getClass().getSimpleName());}}).start();}
  @Override public void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
